import os
import numpy as np
from keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array
from keras.models import Sequential, load_model

img_width, img_height = 150, 150
model_path = './models/model.h5'
model_weights_path = './models/weights.h5'
model = load_model(model_path)
model.load_weights(model_weights_path)

def predict(file):
  x = load_img(file, target_size=(img_width,img_height))
  x = img_to_array(x)
  x = np.expand_dims(x, axis=0)
  array = model.predict(x)
  result = array[0]
  answer = np.argmax(result)
  if answer == 0:
    print("Label: Parasitized")
  elif answer == 1:
    print("Label: Uninfected")
  elif answer == 2:
    print("Label: Sunflower")

  return answer

Parasitized_t = 0
Parasitized_f = 0
Uninfected_t = 0
Uninfected_f = 0

for i, ret in enumerate(os.walk('./test-data/Parasitized')):
  for i, filename in enumerate(ret[2]):
    if filename.startswith("."):
      continue
    #print("Label: Parasitized")
    result = predict(ret[0] + '/' + filename)
    if result == 0:
      Parasitized_t += 1
    else:
      Parasitized_f += 1

for i, ret in enumerate(os.walk('./test-data/Uninfected')):
  for i, filename in enumerate(ret[2]):
    if filename.startswith("."):
      continue
    #print("Label: Uninfected")
    result = predict(ret[0] + '/' + filename)
    if result == 1:
      Uninfected_t += 1
    else:
      Uninfected_f += 1



"""
Check metrics
"""
print("True Parasitized: ", Parasitized_t)
print("False Parasitized: ", Parasitized_f)
print("True Uninfected: ", Uninfected_t)
print("False Uninfected: ", Uninfected_f)

